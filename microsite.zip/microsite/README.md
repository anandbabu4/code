Please have a look at http://www.amasik.com/angularjs-sample-project/
"# demo" 
